module.exports = {
  webpack5: true,
};
